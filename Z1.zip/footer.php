<?php
include 'includes/configuration.php';
include 'includes/extra.php';
?>
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script>
                © <a href="<?php echo $info["url"]; ?>"><?php echo $info["nom"]; ?></a>.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design &amp; Develop by BetterStresser
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="rightbar-overlay"></div>
<!-- JAVASCRIPT -->

</section>
</body>

</html>
